export {
  ObjectStorageService,
  ObjectNotFoundError,
  replitClient,
} from "./objectStorage";

export { registerObjectStorageRoutes } from "./routes";
