import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Navigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Heart, ExternalLink, Sun, Moon } from "lucide-react";
import { useState, useMemo } from "react";
import type { GalleryItem, SiteSettings } from "@shared/schema";

type FilterMode = "all" | "yin" | "yang";

export default function Gallery() {
  const [showTipDialog, setShowTipDialog] = useState(false);
  const [filterMode, setFilterMode] = useState<FilterMode>("all");

  const { data: galleryItems, isLoading } = useQuery<GalleryItem[]>({
    queryKey: ["/api/gallery"],
  });

  const filteredItems = useMemo(() => {
    if (!galleryItems) return [];
    if (filterMode === "all") return galleryItems;
    if (filterMode === "yin") {
      return galleryItems.filter(
        (item) => item.displayMode === "professional" || item.displayMode === "both"
      );
    }
    return galleryItems.filter(
      (item) => item.displayMode === "edge" || item.displayMode === "both"
    );
  }, [galleryItems, filterMode]);

  const { data: settings } = useQuery<SiteSettings>({
    queryKey: ["/api/settings"],
  });

  const { data: paymentMethods = [] } = useQuery<Array<{ id: number; displayName: string; paymentLink: string | null; hasCredentials: boolean }>>({
    queryKey: ["/api/payment-methods/active"],
  });

  const getPaymentLinks = () => {
    return paymentMethods
      .filter(m => m.paymentLink)
      .map(m => ({ name: m.displayName, url: m.paymentLink! }));
  };

  const renderMedia = (item: GalleryItem, isModal = false) => {
    if (item.mediaType === "video") {
      return (
        <video
          src={item.mediaUrl}
          className={isModal ? "max-h-[70vh] max-w-full object-contain" : "w-full h-full object-cover"}
          controls={isModal}
          muted={!isModal}
          loop
          playsInline
          autoPlay={isModal}
        />
      );
    }
    return (
      <img
        src={item.mediaUrl}
        alt={item.title || "Portfolio image"}
        className={isModal ? "max-h-[70vh] max-w-full object-contain" : "w-full h-full object-cover"}
      />
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="font-serif text-4xl md:text-5xl font-normal mb-4" data-testid="text-gallery-title">
              Portfolio
            </h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-6">
              Explore our creative work — websites, videos, mockups, and more.
            </p>
            
            {/* Yin/Yang Filter Buttons */}
            <div className="flex items-center justify-center gap-2 mb-6">
              <Button
                variant={filterMode === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterMode("all")}
                className="rounded-full px-4"
              >
                All Work
              </Button>
              <Button
                variant={filterMode === "yin" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterMode("yin")}
                className="rounded-full px-4 gap-2"
              >
                <Sun className="h-4 w-4" />
                Yin
              </Button>
              <Button
                variant={filterMode === "yang" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterMode("yang")}
                className="rounded-full px-4 gap-2"
              >
                <Moon className="h-4 w-4" />
                Yang
              </Button>
            </div>
            
            {getPaymentLinks().length > 0 && (
              <Button
                size="lg"
                onClick={() => setShowTipDialog(true)}
                className="rounded-full px-8"
                data-testid="button-tip"
              >
                <Heart className="h-5 w-5 mr-2" />
                Show Your Support
              </Button>
            )}
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="aspect-square rounded-lg" />
              ))}
            </div>
          ) : filteredItems.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredItems.map((item) => (
                <Link href={`/projects/${item.id}`} key={item.id}>
                  <Card
                    className="overflow-hidden cursor-pointer hover-elevate group"
                    data-testid={`card-gallery-item-${item.id}`}
                  >
                    <div className="aspect-square overflow-hidden relative">
                      {renderMedia(item)}
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <h3 className="text-white font-medium truncate">
                          {item.title || "View Project"}
                        </h3>
                        <p className="text-white/70 text-sm flex items-center gap-1 mt-1">
                          <ExternalLink className="h-3 w-3" />
                          <span className="truncate">Click to view details</span>
                        </p>
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="mb-4">
                {filterMode === "yin" ? (
                  <Sun className="h-12 w-12 text-muted-foreground/50 mx-auto" />
                ) : filterMode === "yang" ? (
                  <Moon className="h-12 w-12 text-muted-foreground/50 mx-auto" />
                ) : null}
              </div>
              <p className="text-muted-foreground">
                {filterMode === "all" 
                  ? "No projects yet." 
                  : `No ${filterMode === "yin" ? "Yin" : "Yang"} projects yet.`}
              </p>
              {filterMode !== "all" && (
                <p className="text-muted-foreground/70 text-sm mt-2">
                  Try switching to see more work.
                </p>
              )}
            </div>
          )}
        </div>
      </main>

      <Footer />

      <Dialog open={showTipDialog} onOpenChange={setShowTipDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-serif text-xl">Show Your Support</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 pt-4">
            <p className="text-sm text-muted-foreground mb-4">
              Thank you for your support! Choose a payment method below:
            </p>
            {getPaymentLinks().map((link) => (
              <Button
                key={link.name}
                variant="outline"
                className="w-full justify-between"
                onClick={() => window.open(link.url, "_blank")}
                data-testid={`button-tip-${link.name.toLowerCase().replace(" ", "-")}`}
              >
                <span>Support with {link.name}</span>
                <ExternalLink className="h-4 w-4" />
              </Button>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
